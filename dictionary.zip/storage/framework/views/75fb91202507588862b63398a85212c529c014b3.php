<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard
                     <div class="pull-right">
                        <a href="<?php echo e(url('/word/all')); ?>"> All Words</a>
                        |
                        <a href="<?php echo e(url('/word/add')); ?>"> Add Word</a>
                    </div>

                </div>

                <div class="panel-body">
                   
                   <div >
                       
                         <table class="table table-hover">
                            <thead>
                              <tr>
                                <th>Arabic</th>
                                <th>Bangla</th>
                                <th>English</th>
                                <th>Example</th>
                                <th><a href="<?php echo e(url('/word/add')); ?>" class="btn btn-primary">Add New</a></th>
                              </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $words; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $word): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                              <tr>
                                <td><?php echo e($word->ar); ?></td>
                                <td><?php echo e($word->bn); ?></td>
                                <td><?php echo e($word->en); ?></td>
                                <td><?php echo e($word->desc); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/word/edit/'.$word->id)); ?>" class="btn btn-info">Edit</a>
                                    <a href="" class="btn btn-danger">Del</a>

                                </td>
                                
                               
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </tbody>
                          </table>

                    </div>

                    <?php echo e($words->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>