<?php if(Session::has('info')): ?>

<div class="alert alert-info" >
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	 <?php echo e(Session::get('info')); ?>

	
</div>


<?php endif; ?>