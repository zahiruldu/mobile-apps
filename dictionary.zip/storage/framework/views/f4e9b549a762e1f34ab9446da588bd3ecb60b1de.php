<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard
                     <div class="pull-right">
                        <a href="<?php echo e(url('/word/all')); ?>"> All Words</a>
                        |
                        <a href="<?php echo e(url('/word/add')); ?>"> Add Word</a>
                    </div>
                </div>

                <div class="panel-body">
                   <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/word/edit/'.$word->id)); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('ar') ? ' has-error' : ''); ?>">
                            <label for="ar" class="col-md-4 control-label">Arabic</label>

                            <div class="col-md-6">
                                <input id="ar" type="text" class="form-control" name="ar" value="<?php echo e(old('ar')? : $word->ar); ?>"  autofocus>

                                <?php if($errors->has('ar')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('ar')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('en') ? ' has-error' : ''); ?>">
                            <label for="en" class="col-md-4 control-label">English</label>

                            <div class="col-md-6">
                                <input id="en" type="text" class="form-control" name="en" value="<?php echo e(old('en') ? : $word->en); ?>" >

                                <?php if($errors->has('en')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('en')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('bn') ? ' has-error' : ''); ?>">
                            <label for="bn" class="col-md-4 control-label">Bangla</label>

                            <div class="col-md-6">
                                <input id="bn" type="text" class="form-control" name="bn" value="<?php echo e(old('bn') ? : $word->bn); ?>" >

                                <?php if($errors->has('bn')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('bn')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('desc') ? ' has-error' : ''); ?>">
                            <label for="desc" class="col-md-4 control-label">Description</label>

                            <div class="col-md-6">
                                <textarea id="desc" class="form-control" name="desc"><?php echo e(old('desc') ? : $word->desc); ?></textarea>

                                <?php if($errors->has('desc')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('desc')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Update
                                </button>

                                 <button type="reset" class="btn btn-default">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>